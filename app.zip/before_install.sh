#!/bin/bash
sudo apt update -y
sudo apt install apache2 unzip -y  # Install Apache and Unzip if not installed
sudo systemctl stop apache2  # Stop Apache before deployment
