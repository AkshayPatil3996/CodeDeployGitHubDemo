#!/bin/bash
sudo systemctl start apache2  # Restart Apache