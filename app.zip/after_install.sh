#!/bin/bash
sudo rm -rf /var/www/html/*  # Remove old application files
sudo cp -r /home/ubuntu/deploy/* /var/www/html/  # Copy new files
sudo chmod -R 755 /var/www/html/  # Set permissions
sudo chown -R www-data:www-data /var/www/html/  # Set correct ownership
